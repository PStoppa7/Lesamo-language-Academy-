# Nthabeleng Tutor Platform

A professional tutoring platform for students to practice, submit assignments, and track their learning progress.

## Features

- 🔐 User authentication (signup/login)
- 📤 Assignment submission system
- 📊 Progress tracking
- 📝 Practice questions with immediate feedback
- 👨‍💼 Admin dashboard for managing submissions
- 📈 Analytics and reporting

## Tech Stack

- **Backend:** Node.js, Express.js
- **Security:** Helmet, bcrypt, express-rate-limit, XSS protection
- **File Upload:** Multer
- **Session Management:** express-session
- **Frontend:** Vanilla JavaScript, HTML5, CSS3

## Prerequisites

- Node.js >= 16
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd files
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Start the development server:
```bash
npm run dev
```

Or for production:
```bash
npm start
```

5. Open your browser and navigate to:
```
http://localhost:3000
```

## Environment Variables

See `.env.example` for all available configuration options.

**Required for production:**
- `SESSION_SECRET` - A strong random string for session encryption
- `ADMIN_USER` - Admin username
- `ADMIN_PASS` - Admin password (use strong password)
- `NODE_ENV` - Set to `production` for production

## Project Structure

```
files/
├── server.js              # Main server file
├── package.json           # Dependencies and scripts
├── data.json             # Data storage (JSON - migrate to DB for production)
├── submissions/          # Uploaded files directory
├── public/               # Public static files
│   ├── index.html        # Homepage
│   ├── login.html        # Login page
│   ├── signup.html       # Signup page
│   ├── styles.css        # Main stylesheet
│   ├── login.js          # Login functionality
│   ├── signup.js         # Signup functionality
│   ├── practice.js       # Practice questions
│   ├── progress.js       # Progress tracking
│   └── dashboard.js      # Dashboard functionality
└── Private/              # Protected files
    └── dashboard.html    # Student dashboard
```

## API Endpoints

### Authentication
- `POST /signup` - Create new user account
- `POST /login` - User login
- `GET /logout` - User logout

### User Endpoints
- `GET /api/progress` - Get user progress
- `POST /api/progress` - Save user progress
- `POST /api/submit` - Submit assignment (requires auth)
- `GET /api/submissions` - Get user submissions (requires auth)

### Admin Endpoints (Basic Auth Required)
- `GET /admin/progress` - View all user progress
- `GET /admin/progress.csv` - Export progress as CSV
- `GET /admin/submissions` - View all submissions
- `GET /admin/submissions/:id/download` - Download submission file

## Security Features

- Password hashing with bcrypt
- Session-based authentication
- Rate limiting on auth endpoints
- XSS protection
- Helmet.js security headers
- File upload validation
- Secure session cookies

## Development

### Running in Development Mode

```bash
npm run dev
```

This uses `nodemon` to automatically restart the server on file changes.

### Adding New Features

1. Create feature branch
2. Implement changes
3. Test thoroughly
4. Update documentation
5. Submit pull request

## Production Deployment

### Before Deploying:

1. **Migrate from JSON to Database**
   - Current `data.json` storage is not suitable for production
   - Use PostgreSQL or MongoDB

2. **Set Strong Environment Variables**
   - Generate strong `SESSION_SECRET`
   - Set secure `ADMIN_USER` and `ADMIN_PASS`
   - Configure `NODE_ENV=production`

3. **Enable HTTPS**
   - Use Let's Encrypt for free SSL
   - Configure reverse proxy (nginx)

4. **Set Up Backups**
   - Database backups
   - File upload backups
   - Automated backup schedule

5. **Configure Monitoring**
   - Error tracking (Sentry)
   - Uptime monitoring
   - Log aggregation

### Deployment Options

- **Railway:** Easy Node.js deployment
- **Render:** Free tier available
- **Heroku:** Popular platform
- **DigitalOcean:** VPS with full control
- **AWS:** Enterprise-grade hosting

## Known Limitations

- ⚠️ **JSON File Storage:** Not suitable for production. Migrate to database.
- ⚠️ **No Email System:** Password reset and notifications not implemented
- ⚠️ **No Payment Integration:** If selling, add payment processing
- ⚠️ **Basic Admin Panel:** Needs UI improvements
- ⚠️ **Single Practice Question:** Needs question bank

See `PROFESSIONAL_IMPROVEMENTS.md` for complete improvement roadmap.

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

[Specify your license here]

## Support

For support, email [your-email] or open an issue in the repository.

## Roadmap

See `PROFESSIONAL_IMPROVEMENTS.md` for detailed roadmap of planned features and improvements.

---

**Note:** This is a development version. For production use, implement the improvements outlined in `PROFESSIONAL_IMPROVEMENTS.md`.




