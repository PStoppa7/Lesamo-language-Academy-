# Quick Start Guide - Making Your Site Professional

This guide provides step-by-step instructions for the most critical improvements to make your site production-ready.

## 🚀 Phase 1: Foundation (Week 1)

### Step 1: Set Up Environment Variables

1. Create a `.env` file in the root directory:
```bash
PORT=3000
NODE_ENV=production
SESSION_SECRET=generate-a-random-32-character-string-here
ADMIN_USER=your-admin-username
ADMIN_PASS=your-strong-admin-password
BCRYPT_ROUNDS=12
```

2. Generate a secure SESSION_SECRET:
```bash
# On Linux/Mac:
openssl rand -base64 32

# Or use Node.js:
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

### Step 2: Add CSRF Protection

Install CSRF package:
```bash
npm install csurf
```

Add to `server.js`:
```javascript
const csrf = require('csurf');
const csrfProtection = csrf({ cookie: true });

// Apply to all POST routes
app.post('/signup', csrfProtection, async (req, res) => {
  // ... existing code
});

// Add CSRF token to forms
app.get('/signup.html', csrfProtection, (req, res) => {
  res.cookie('XSRF-TOKEN', req.csrfToken());
  res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});
```

### Step 3: Create Error Pages

Create `public/404.html`:
```html
<!DOCTYPE html>
<html>
<head>
  <title>404 - Page Not Found</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <h1>404 - Page Not Found</h1>
    <p>The page you're looking for doesn't exist.</p>
    <a href="/" class="btn primary">Go Home</a>
  </div>
</body>
</html>
```

Add to `server.js`:
```javascript
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});
```

### Step 4: Add Structured Logging

Install Winston:
```bash
npm install winston
```

Create `utils/logger.js`:
```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}

module.exports = logger;
```

Use in `server.js`:
```javascript
const logger = require('./utils/logger');
// Replace console.error with logger.error
```

---

## 🗄️ Phase 2: Database Migration (Week 2)

### Option A: PostgreSQL (Recommended)

1. Install dependencies:
```bash
npm install pg
```

2. Create `db/connection.js`:
```javascript
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

module.exports = pool;
```

3. Create migration script `db/migrations/001_initial.sql`:
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE submissions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  title VARCHAR(255) NOT NULL,
  type VARCHAR(50),
  filename VARCHAR(255),
  stored_filename VARCHAR(255),
  filepath TEXT,
  notes TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE progress (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  data JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

4. Update `server.js` to use database instead of JSON file.

### Option B: MongoDB

1. Install dependencies:
```bash
npm install mongoose
```

2. Create `db/connection.js`:
```javascript
const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

module.exports = mongoose;
```

3. Create models in `models/` directory.

---

## 📧 Phase 3: Email System (Week 3)

### Step 1: Install Nodemailer

```bash
npm install nodemailer
```

### Step 2: Create Email Service

Create `services/email.js`:
```javascript
const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

async function sendEmail(to, subject, html) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to,
      subject,
      html
    });
    return true;
  } catch (error) {
    console.error('Email error:', error);
    return false;
  }
}

module.exports = { sendEmail };
```

### Step 3: Add Email Verification

1. Add `email_verified` field to users table
2. Generate verification token on signup
3. Send verification email
4. Add verification route

### Step 4: Add Password Reset

1. Create password reset tokens table
2. Add `/forgot-password` route
3. Add `/reset-password/:token` route
4. Send reset email with token

---

## 🧪 Phase 4: Testing (Week 4)

### Step 1: Install Testing Dependencies

```bash
npm install --save-dev jest supertest
```

### Step 2: Create Test Structure

```
tests/
  ├── unit/
  │   └── auth.test.js
  ├── integration/
  │   └── api.test.js
  └── setup.js
```

### Step 3: Add Test Scripts to package.json

```json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage"
  }
}
```

### Step 4: Write Basic Tests

Example `tests/integration/api.test.js`:
```javascript
const request = require('supertest');
const app = require('../../server');

describe('POST /signup', () => {
  it('should create a new user', async () => {
    const res = await request(app)
      .post('/signup')
      .send({
        username: 'testuser',
        email: 'test@example.com',
        password: 'Test123!@#'
      });
    expect(res.statusCode).toBe(201);
  });
});
```

---

## 🔒 Security Checklist

- [ ] Strong SESSION_SECRET set
- [ ] CSRF protection enabled
- [ ] Rate limiting configured
- [ ] Password validation enforced
- [ ] HTTPS enabled (production)
- [ ] Environment variables secured
- [ ] SQL injection prevention (if using SQL)
- [ ] XSS protection (already implemented)
- [ ] File upload validation (already implemented)
- [ ] Session timeout configured

---

## 📦 Deployment Checklist

Before deploying to production:

- [ ] All environment variables set
- [ ] Database migrated and tested
- [ ] Error logging configured
- [ ] Email service tested
- [ ] HTTPS/SSL configured
- [ ] Backups configured
- [ ] Monitoring set up
- [ ] Error tracking (Sentry) configured
- [ ] Performance tested
- [ ] Security audit completed

---

## 🆘 Common Issues & Solutions

### Issue: "Session secret not set"
**Solution:** Set SESSION_SECRET in .env file

### Issue: "Database connection failed"
**Solution:** Check DATABASE_URL in .env and ensure database is running

### Issue: "Email not sending"
**Solution:** 
- Check SMTP credentials
- For Gmail, use App Password (not regular password)
- Check firewall/network settings

### Issue: "CSRF token mismatch"
**Solution:** Ensure CSRF token is included in form submissions

---

## 📚 Additional Resources

- [Express.js Security Best Practices](https://expressjs.com/en/advanced/best-practice-security.html)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Node.js Production Best Practices](https://github.com/goldbergyoni/nodebestpractices)

---

**Need Help?** Refer to `PROFESSIONAL_IMPROVEMENTS.md` for detailed explanations of each improvement.




