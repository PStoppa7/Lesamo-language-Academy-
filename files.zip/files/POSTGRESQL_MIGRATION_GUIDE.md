# PostgreSQL Migration Guide

This guide will walk you through replacing the JSON file storage with PostgreSQL.

## Prerequisites

1. **PostgreSQL installed** on your system or access to a PostgreSQL database
   - Local: Download from [postgresql.org](https://www.postgresql.org/download/)
   - Cloud: Use services like [Supabase](https://supabase.com), [Railway](https://railway.app), [Render](https://render.com), or [ElephantSQL](https://www.elephantsql.com)

2. **Node.js** (already installed)

## Step 1: Install Dependencies

```bash
npm install
```

This will install the `pg` package that was added to `package.json`.

## Step 2: Set Up PostgreSQL Database

### Option A: Local PostgreSQL

1. Create a new database:
```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE tutoring_db;

# Create a user (optional but recommended)
CREATE USER tutoring_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE tutoring_db TO tutoring_user;

# Exit
\q
```

### Option B: Cloud PostgreSQL (Recommended for Production)

1. Sign up for a free PostgreSQL service:
   - **Supabase**: Free tier, easy setup
   - **Railway**: Free tier available
   - **Render**: Free tier available
   - **ElephantSQL**: Free tier available

2. Get your connection string (DATABASE_URL) from the service dashboard

## Step 3: Configure Environment Variables

Add to your `.env` file:

```env
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/tutoring_db

# For cloud services, use the connection string provided:
# DATABASE_URL=postgresql://user:pass@host:5432/dbname?sslmode=require
```

**Important:** 
- Replace `username`, `password`, `localhost`, `5432`, and `tutoring_db` with your actual values
- For cloud services, use the full connection string they provide
- Never commit `.env` to version control!

## Step 4: Create Database Tables

Run the SQL schema to create all necessary tables:

### Option A: Using psql command line

```bash
psql -U postgres -d tutoring_db -f db/schema.sql
```

### Option B: Using a database GUI

1. Open your database in a tool like:
   - pgAdmin
   - DBeaver
   - TablePlus
   - Supabase Dashboard

2. Copy the contents of `db/schema.sql`
3. Execute it in your database

### Option C: Using Node.js script

Create a file `db/init.js`:

```javascript
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function initDatabase() {
  try {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(schema);
    console.log('Database schema created successfully!');
  } catch (err) {
    console.error('Error creating schema:', err);
  } finally {
    await pool.end();
  }
}

initDatabase();
```

Run it:
```bash
node db/init.js
```

## Step 5: Migrate Existing Data (Optional)

If you have existing data in `data.json`, migrate it:

```bash
node db/migrate.js
```

This will:
- Read your existing `data.json` file
- Create users, submissions, and progress entries in PostgreSQL
- Create a backup file `data.json.backup`

**Note:** After verifying the migration worked, you can delete `data.json` (keep the backup for safety).

## Step 6: Test the Migration

1. Start your server:
```bash
npm start
```

2. Test the following:
   - Sign up a new user
   - Log in
   - Submit an assignment
   - View progress
   - Check admin panel

3. Verify data is in PostgreSQL:
```bash
psql -U postgres -d tutoring_db

# Check users
SELECT * FROM users;

# Check submissions
SELECT * FROM submissions;

# Check progress
SELECT * FROM progress;

# Exit
\q
```

## Step 7: Update Your Code

The code has already been updated! All `readData()` and `writeData()` calls have been replaced with database functions.

## Troubleshooting

### Error: "Connection refused"

**Solution:** 
- Check if PostgreSQL is running: `pg_isready` or check service status
- Verify DATABASE_URL is correct
- Check firewall settings

### Error: "password authentication failed"

**Solution:**
- Verify username and password in DATABASE_URL
- Check PostgreSQL user permissions

### Error: "relation does not exist"

**Solution:**
- Make sure you ran the schema.sql file
- Check table names match (case-sensitive in PostgreSQL)

### Error: "too many clients"

**Solution:**
- The connection pool might be exhausted
- Check for connection leaks (connections not being closed)
- Increase pool size in `db/connection.js` if needed

### Data not appearing

**Solution:**
- Check if migration script ran successfully
- Verify DATABASE_URL points to the correct database
- Check server logs for errors

## Verification Checklist

- [ ] PostgreSQL is installed and running
- [ ] Database created
- [ ] Tables created (users, submissions, progress)
- [ ] DATABASE_URL set in .env
- [ ] Dependencies installed (`npm install`)
- [ ] Server starts without errors
- [ ] Can create new users
- [ ] Can log in
- [ ] Can submit assignments
- [ ] Admin panel works
- [ ] Data persists after server restart

## Next Steps

After successful migration:

1. **Remove JSON file dependency** (optional):
   - Delete or rename `data.json` after verifying everything works
   - Keep `data.json.backup` as a safety backup

2. **Set up database backups**:
   - Configure automated backups
   - Test restore process

3. **Monitor performance**:
   - Check query performance
   - Add indexes if needed (already included in schema)

4. **Production considerations**:
   - Use connection pooling (already implemented)
   - Set up database monitoring
   - Configure SSL for production connections

## File Structure

After migration, your project structure includes:

```
files/
├── db/
│   ├── connection.js      # Database connection pool
│   ├── database.js         # Database service layer (replaces readData/writeData)
│   ├── schema.sql          # Database schema
│   └── migrate.js          # Data migration script
├── server.js               # Updated to use PostgreSQL
└── package.json            # Includes pg dependency
```

## Support

If you encounter issues:

1. Check server logs for error messages
2. Verify DATABASE_URL format
3. Test database connection separately
4. Review PostgreSQL logs
5. Check the troubleshooting section above

---

**Congratulations!** Your application now uses PostgreSQL instead of JSON file storage. This is much more scalable and production-ready! 🎉




